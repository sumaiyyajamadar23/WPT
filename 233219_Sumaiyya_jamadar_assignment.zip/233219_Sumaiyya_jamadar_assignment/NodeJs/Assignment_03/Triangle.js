exports.tPerimeter=function(a,b,c){
    return a+b+c;
}
exports.isEquilateral=function(a,b,c){
    if(a===b===c){
        return true;
    }
    return false;
}