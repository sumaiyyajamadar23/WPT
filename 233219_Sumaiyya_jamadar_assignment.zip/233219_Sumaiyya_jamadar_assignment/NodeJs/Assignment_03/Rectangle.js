exports.area=function(l,b){
    return l*b;
}
exports.perimeter=function(l,b){
    return 2*(l+b);
}